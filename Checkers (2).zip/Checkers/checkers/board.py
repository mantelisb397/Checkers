import pygame

from .constants import (
    BOARD_BLACK,
    BOARD_WHITE,
    COLS,
    RED,
    ROWS,
    SQUARE_SIZE,
    WHITE,
)
from .piece_factory import PieceFactory


class Board:
    def __init__(self):
        self.board = []
        self.red_left = self.white_left = 12
        self.red_kings = self.white_kings = 0
        self.create_board()

    def draw_squares(self, win):
        win.fill(BOARD_WHITE)
        for row in range(ROWS):
            for col in range(COLS):
                if (row + col) % 2 == 1:
                    pygame.draw.rect(
                        win,
                        BOARD_BLACK,
                        (
                            col * SQUARE_SIZE,
                            row * SQUARE_SIZE,
                            SQUARE_SIZE,
                            SQUARE_SIZE,
                        ),
                    )

    def move(self, piece, row, col):
        """Move a selected piece and promote it if it reaches the last row."""
        self.board[piece.row][piece.col] = 0
        self.board[row][col] = piece
        piece.move(row, col)

        if row == ROWS - 1 or row == 0:
            self._promote_to_king(piece)

    def _promote_to_king(self, piece):
        """Replace a normal piece with a king piece."""
        if piece.king:
            return

        king_piece = PieceFactory.create_piece(
            "king",
            piece.row,
            piece.col,
            piece.color,
        )
        self.board[piece.row][piece.col] = king_piece

        if piece.color == WHITE:
            self.white_kings += 1
        else:
            self.red_kings += 1

    def get_piece(self, row, col):
        return self.board[row][col]

    def create_board(self):
        """Create the initial Checkers board setup."""
        for row in range(ROWS):
            self.board.append([])
            for col in range(COLS):
                if col % 2 == ((row + 1) % 2):
                    if row < 3:
                        self.board[row].append(
                            PieceFactory.create_piece("man", row, col, WHITE)
                        )
                    elif row > 4:
                        self.board[row].append(
                            PieceFactory.create_piece("man", row, col, RED)
                        )
                    else:
                        self.board[row].append(0)
                else:
                    self.board[row].append(0)

    def draw(self, win):
        self.draw_squares(win)
        for row in range(ROWS):
            for col in range(COLS):
                piece = self.board[row][col]
                if piece != 0:
                    piece.draw(win)

    def remove(self, pieces):
        """Remove captured pieces from the board."""
        for piece in pieces:
            self.board[piece.row][piece.col] = 0
            if piece != 0:
                if piece.color == RED:
                    self.red_left -= 1
                else:
                    self.white_left -= 1

    def winner(self):
        if self.red_left <= 0:
            return WHITE
        if self.white_left <= 0:
            return RED
        return None

    def get_valid_moves(self, piece):
        """Return all legal moves for the selected piece."""
        if piece.king:
            return self._get_king_moves(piece)

        moves = {}
        row = piece.row

        for direction in piece.get_move_directions():
            moves.update(
                self._traverse_left(
                    row + direction,
                    self._get_stop_row(row, direction),
                    direction,
                    piece.color,
                    piece.col - 1,
                )
            )
            moves.update(
                self._traverse_right(
                    row + direction,
                    self._get_stop_row(row, direction),
                    direction,
                    piece.color,
                    piece.col + 1,
                )
            )

        return moves

    def _get_king_moves(self, piece):
        """Return valid moves for a flying king piece."""
        moves = {}

        directions = [
            (-1, -1),
            (-1, 1),
            (1, -1),
            (1, 1),
        ]

        for row_step, col_step in directions:
            moves.update(
                self._traverse_king_direction(
                    piece.row + row_step,
                    piece.col + col_step,
                    row_step,
                    col_step,
                    piece.color,
                    skipped=[],
                )
            )

        return moves

    def _traverse_king_direction(
        self,
        row,
        col,
        row_step,
        col_step,
        color,
        skipped=None,
    ):
        """Traverse one diagonal direction for a flying king."""
        if skipped is None:
            skipped = []

        moves = {}
        captured_piece = None

        while 0 <= row < ROWS and 0 <= col < COLS:
            current = self.board[row][col]

            if current == 0:
                if captured_piece is None:
                    if not skipped:
                        moves[(row, col)] = []
                else:
                    captured_list = skipped + [captured_piece]
                    moves[(row, col)] = captured_list

                    moves.update(
                        self._continue_king_capture(
                            row,
                            col,
                            color,
                            captured_list,
                        )
                    )

            else:
                if current.color == color:
                    break

                if captured_piece is not None:
                    break

                if current in skipped:
                    break

                captured_piece = current

            row += row_step
            col += col_step

        return moves

    def _continue_king_capture(self, row, col, color, skipped):
        """Check additional captures after a king has already captured."""
        moves = {}

        directions = [
            (-1, -1),
            (-1, 1),
            (1, -1),
            (1, 1),
        ]

        for row_step, col_step in directions:
            next_row = row + row_step
            next_col = col + col_step

            moves.update(
                self._traverse_king_direction(
                    next_row,
                    next_col,
                    row_step,
                    col_step,
                    color,
                    skipped=skipped,
                )
            )

        return moves

    @staticmethod
    def _get_stop_row(row, direction):
        if direction == -1:
            return max(row - 3, -1)
        return min(row + 3, ROWS)

    def _traverse_left(self, start, stop, step, color, left, skipped=None):
        if skipped is None:
            skipped = []

        moves = {}
        last = []

        for r in range(start, stop, step):
            if left < 0:
                break

            current = self.board[r][left]

            if current == 0:
                if skipped and not last:
                    break

                if skipped:
                    moves[(r, left)] = last + skipped
                else:
                    moves[(r, left)] = last

                if last:
                    row = self._get_stop_row(r, step)
                    moves.update(
                        self._traverse_left(
                            r + step,
                            row,
                            step,
                            color,
                            left - 1,
                            skipped=last,
                        )
                    )
                    moves.update(
                        self._traverse_right(
                            r + step,
                            row,
                            step,
                            color,
                            left + 1,
                            skipped=last,
                        )
                    )
                break

            if current.color == color:
                break

            last = [current]
            left -= 1

        return moves

    def _traverse_right(self, start, stop, step, color, right, skipped=None):
        if skipped is None:
            skipped = []

        moves = {}
        last = []

        for r in range(start, stop, step):
            if right >= COLS:
                break

            current = self.board[r][right]

            if current == 0:
                if skipped and not last:
                    break

                if skipped:
                    moves[(r, right)] = last + skipped
                else:
                    moves[(r, right)] = last

                if last:
                    row = self._get_stop_row(r, step)
                    moves.update(
                        self._traverse_left(
                            r + step,
                            row,
                            step,
                            color,
                            right - 1,
                            skipped=last,
                        )
                    )
                    moves.update(
                        self._traverse_right(
                            r + step,
                            row,
                            step,
                            color,
                            right + 1,
                            skipped=last,
                        )
                    )
                break

            if current.color == color:
                break

            last = [current]
            right += 1

        return moves