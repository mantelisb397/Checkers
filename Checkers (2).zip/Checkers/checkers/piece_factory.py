#Factory Method implementation for creating Checkers pieces

from .piece import KingPiece, ManPiece


class PieceFactory:
    """Creates piece objects without exposing concrete classes to Board."""

    @staticmethod
    def create_piece(piece_type, row, col, color):
        if piece_type == "man":
            return ManPiece(row, col, color)
        if piece_type == "king":
            return KingPiece(row, col, color)
        raise ValueError(f"Unknown piece type: {piece_type}")