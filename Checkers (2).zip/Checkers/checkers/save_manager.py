#Save/load functionality for the Checkers game

import json

from .constants import RED, WHITE
from .piece_factory import PieceFactory


class SaveManager:
    """Handles writing and reading game state to/from JSON files."""

    COLOR_TO_NAME = {
        RED: "red",
        WHITE: "white",
    }

    NAME_TO_COLOR = {
        "red": RED,
        "white": WHITE,
    }

    @classmethod
    def save_game(cls, board, turn, filename="savegame.json"):
        data = {
            "turn": cls.COLOR_TO_NAME[turn],
            "red_left": board.red_left,
            "white_left": board.white_left,
            "red_kings": board.red_kings,
            "white_kings": board.white_kings,
            "pieces": [],
        }

        for row in board.board:
            for piece in row:
                if piece != 0:
                    data["pieces"].append(
                        {
                            "row": piece.row,
                            "col": piece.col,
                            "color": cls.COLOR_TO_NAME[piece.color],
                            "type": "king" if piece.king else "man",
                        }
                    )

        with open(filename, "w", encoding="utf-8") as file:
            json.dump(data, file, indent=4)

    @classmethod
    def load_game(cls, board, filename="savegame.json"):
        with open(filename, "r", encoding="utf-8") as file:
            data = json.load(file)

        board.board = [[0 for _ in range(8)] for _ in range(8)]
        board.red_left = data["red_left"]
        board.white_left = data["white_left"]
        board.red_kings = data["red_kings"]
        board.white_kings = data["white_kings"]

        for item in data["pieces"]:
            piece = PieceFactory.create_piece(
                item["type"],
                item["row"],
                item["col"],
                cls.NAME_TO_COLOR[item["color"]],
            )
            board.board[item["row"]][item["col"]] = piece

        return cls.NAME_TO_COLOR[data["turn"]]