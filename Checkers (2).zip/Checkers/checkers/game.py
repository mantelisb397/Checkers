#User input, turns and rendering

import pygame

from .board import Board
from .constants import GREEN, RED, SQUARE_SIZE, WHITE
from .save_manager import SaveManager


class Game:

    def __init__(self, win):
        self.win = win
        self._init()

    def _init(self):
        self.selected = None
        self.board = Board()
        self.turn = RED
        self.valid_moves = {}

    def update(self):
        self.board.draw(self.win)
        self.draw_valid_moves(self.valid_moves)
        pygame.display.update()

    def winner(self):
        return self.board.winner()

    def reset(self):
        self._init()

    def select(self, row, col):
        """Select a piece or move the currently selected piece."""
        if self.selected:
            result = self._move(row, col)
            if not result:
                self.selected = None
                self.select(row, col)

        piece = self.board.get_piece(row, col)
        if piece != 0 and piece.color == self.turn:
            self.selected = piece
            self.valid_moves = self.board.get_valid_moves(piece)
            return True

        return False

    def _move(self, row, col):
        piece = self.board.get_piece(row, col)

        if self.selected and piece == 0 and (row, col) in self.valid_moves:
            self.board.move(self.selected, row, col)

            skipped = self.valid_moves[(row, col)]
            if skipped:
                self.board.remove(skipped)

            self.change_turn()
            return True

        return False

    def draw_valid_moves(self, moves):
        for move in moves:
            row, col = move
            pygame.draw.circle(
                self.win,
                GREEN,
                (
                    col * SQUARE_SIZE + SQUARE_SIZE // 2,
                    row * SQUARE_SIZE + SQUARE_SIZE // 2,
                ),
                15,
            )

    def change_turn(self):
        self.valid_moves = {}
        self.selected = None

        if self.turn == RED:
            self.turn = WHITE
        else:
            self.turn = RED

    def save_game(self, filename="savegame.json"):
        SaveManager.save_game(self.board, self.turn, filename)

    def load_game(self, filename="savegame.json"):
        self.turn = SaveManager.load_game(self.board, filename)
        self.selected = None
        self.valid_moves = {}

    @staticmethod
    def turn_name(turn):
        if turn == RED:
            return "RED"
        if turn == WHITE:
            return "WHITE"
        return str(turn)