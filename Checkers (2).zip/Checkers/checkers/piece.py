#Piece classes used in the Checkers game

from abc import ABC, abstractmethod

import pygame

from .constants import CROWN, GOLD, GREY, RED, SQUARE_SIZE


class BasePiece(ABC):
    """Abstract base class for all Checkers pieces."""

    PADDING = 15
    OUTLINE = 2

    def __init__(self, row, col, color):
        self._row = row
        self._col = col
        self._color = color
        self._x = 0
        self._y = 0
        self.calc_pos()

    @property
    def row(self):
        return self._row

    @property
    def col(self):
        return self._col

    @property
    def color(self):
        return self._color

    @property
    def x(self):
        return self._x

    @property
    def y(self):
        return self._y

    @property
    @abstractmethod
    def king(self):
        """Return whether this piece is a king."""

    @abstractmethod
    def get_move_directions(self):
        """Return row directions this piece can move in."""

    def calc_pos(self):
        """Calculate the piece centre position in pixels."""
        self._x = SQUARE_SIZE * self._col + SQUARE_SIZE // 2
        self._y = SQUARE_SIZE * self._row + SQUARE_SIZE // 2

    def move(self, row, col):
        """Move the piece to a new board position."""
        self._row = row
        self._col = col
        self.calc_pos()

    def draw(self, win):
        """Draw the piece on the Pygame window."""
        radius = SQUARE_SIZE // 2 - self.PADDING
        pygame.draw.circle(win, GREY, (self.x, self.y), radius + self.OUTLINE)
        pygame.draw.circle(win, self.color, (self.x, self.y), radius)

        if self.king:
            if CROWN is not None:
                win.blit(
                    CROWN,
                    (
                        self.x - CROWN.get_width() // 2,
                        self.y - CROWN.get_height() // 2,
                    ),
                )
            else:
                pygame.draw.circle(win, GOLD, (self.x, self.y), radius // 2)

    def __repr__(self):
        return str(self.color)


class ManPiece(BasePiece):
    """Normal Checkers piece."""

    @property
    def king(self):
        return False

    def get_move_directions(self):
        if self.color == RED:
            return [-1]
        return [1]


class KingPiece(BasePiece):
    """King piece that can move both upward and downward."""

    @property
    def king(self):
        return True

    def get_move_directions(self):
        return [-1, 1]


Piece = ManPiece