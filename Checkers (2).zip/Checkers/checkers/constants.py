from pathlib import Path

import pygame

WIDTH, HEIGHT = 800, 800
ROWS, COLS = 8, 8
SQUARE_SIZE = WIDTH // COLS

BOARD_WHITE = (238, 238, 238)
BOARD_BLACK = (38, 38, 38)

RED = (178, 63, 63)
WHITE = (224, 218, 205)

GREY = (105, 105, 105)
GREEN = (76, 175, 80)
GOLD = (232, 190, 92)

ASSETS_DIR = Path(__file__).resolve().parent.parent / "assets"
CROWN_PATH = ASSETS_DIR / "crown.png"


def load_crown_image():
    try:
        return pygame.transform.scale(
            pygame.image.load(str(CROWN_PATH)),
            (44, 25),
        )
    except pygame.error:
        return None


CROWN = load_crown_image()