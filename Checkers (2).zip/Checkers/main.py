import pygame

from checkers.constants import HEIGHT, SQUARE_SIZE, WIDTH
from checkers.game import Game

FPS = 60

WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Checkers OOP")


def get_row_col_from_mouse(pos):
    x, y = pos
    row = y // SQUARE_SIZE
    col = x // SQUARE_SIZE
    return row, col


def main():
    run = True
    clock = pygame.time.Clock()
    game = Game(WIN)

    while run:
        clock.tick(FPS)

        if game.winner() is not None:
            print("Winner:", game.turn_name(game.winner()))
            run = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                row, col = get_row_col_from_mouse(pos)
                game.select(row, col)

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    game.reset()
                elif event.key == pygame.K_s:
                    game.save_game()
                    print("Game saved to savegame.json")
                elif event.key == pygame.K_l:
                    game.load_game()
                    print("Game loaded from savegame.json")

        game.update()

    pygame.quit()


if __name__ == "__main__":
    main()