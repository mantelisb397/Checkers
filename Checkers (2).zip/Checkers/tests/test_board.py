"""Unit tests for core Checkers board functionality."""

import unittest

from checkers.board import Board
from checkers.constants import RED, WHITE
from checkers.piece_factory import PieceFactory


class TestBoard(unittest.TestCase):
    def test_initial_piece_counts(self):
        board = Board()
        self.assertEqual(board.red_left, 12)
        self.assertEqual(board.white_left, 12)

    def test_red_piece_has_initial_moves(self):
        board = Board()
        piece = board.get_piece(5, 0)
        moves = board.get_valid_moves(piece)
        self.assertIn((4, 1), moves)

    def test_piece_cannot_move_to_occupied_square(self):
        board = Board()
        piece = board.get_piece(5, 0)
        moves = board.get_valid_moves(piece)
        self.assertNotIn((5, 0), moves)

    def test_capture_move_is_detected(self):
        board = Board()
        board.board = [[0 for _ in range(8)] for _ in range(8)]

        red_piece = PieceFactory.create_piece("man", 5, 0, RED)
        white_piece = PieceFactory.create_piece("man", 4, 1, WHITE)

        board.board[5][0] = red_piece
        board.board[4][1] = white_piece

        moves = board.get_valid_moves(red_piece)

        self.assertIn((3, 2), moves)
        self.assertEqual(moves[(3, 2)], [white_piece])

    def test_winner_when_white_has_no_pieces(self):
        board = Board()
        board.white_left = 0
        self.assertEqual(board.winner(), RED)


if __name__ == "__main__":
    unittest.main()