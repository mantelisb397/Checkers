"""Unit tests for saving and loading game state."""

import os
import tempfile
import unittest

from checkers.board import Board
from checkers.constants import RED
from checkers.save_manager import SaveManager


class TestSaveManager(unittest.TestCase):
    def test_save_and_load_preserves_turn_and_counts(self):
        board = Board()

        with tempfile.NamedTemporaryFile(delete=False) as temp_file:
            filename = temp_file.name

        try:
            SaveManager.save_game(board, RED, filename)
            loaded_board = Board()
            turn = SaveManager.load_game(loaded_board, filename)

            self.assertEqual(turn, RED)
            self.assertEqual(loaded_board.red_left, 12)
            self.assertEqual(loaded_board.white_left, 12)
        finally:
            os.remove(filename)


if __name__ == "__main__":
    unittest.main()